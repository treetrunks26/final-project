<?php

namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Prompts;
use App\Http\Requests\PromptRequest;

class PromptController extends Controller
{

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Prompts::all();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(PromptRequest $request)
    {
        $validated = $request->validated();

        $prompt = Prompts::create($validated);

        return $prompt;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $prompt = Prompts::findOrFail($id);

        $prompt->delete();

        return $prompt;
    }

    public function destroyall()
    {
        Prompts::query()->delete();
        return 'Delete ALL Successfully';
    }





}